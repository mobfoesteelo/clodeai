#!/usr/bin/env node
/**
 * CLODE BOT — runs locally on your laptop
 * 
 * Setup:
 *   1. Set env vars (or edit CONFIG below directly)
 *   2. node clode-bot.js --auto        → post 8x/day + reply to mentions forever
 *   3. node clode-bot.js --generate    → preview a tweet without posting
 *   4. node clode-bot.js --post "text" → post specific text right now
 *   5. node clode-bot.js --launch https://i.imgur.com/pfp.jpg  → launch $CLODE token
 * 6. node clode-bot.js               → interactive mode
 * 
 * Required env vars:
 *   OPENAI_KEY            (or ANTHROPIC_KEY if you prefer Claude)
 *   X_CONSUMER_KEY
 *   X_CONSUMER_SECRET
 *   X_ACCESS_TOKEN
 *   X_ACCESS_SECRET
 */

const https    = require('https');
const crypto   = require('crypto');
const readline = require('readline');

// ─── CONFIG ──────────────────────────────────────────────────────────────────
const CONFIG = {
  // AI — uses OpenAI by default, falls back to Anthropic if no OpenAI key
  OPENAI_KEY:         process.env.OPENAI_KEY         || '',
  ANTHROPIC_KEY:      process.env.ANTHROPIC_KEY      || '',

  // X / Twitter API v2 keys (OAuth 1.0a — needs Read+Write)
  X_CONSUMER_KEY:     process.env.X_CONSUMER_KEY     || '',
  X_CONSUMER_SECRET:  process.env.X_CONSUMER_SECRET  || '',
  X_ACCESS_TOKEN:     process.env.X_ACCESS_TOKEN     || '',
  X_ACCESS_SECRET:    process.env.X_ACCESS_SECRET    || '',

  // Bot behavior
  TWEETS_PER_DAY:     8,       // how many original tweets per day
  REPLY_INTERVAL_MS:  2 * 60 * 1000,   // check mentions every 2 min
  X_HANDLE:           '@_ClodeAi',
  WALLET:             process.env.WALLET || 'AW2bp3akizAbHsefNARnhNVzRmgYnDkaiafzpH7jnbTw',
};

// ─── PERSONA ─────────────────────────────────────────────────────────────────
const PERSONA = `you are clode. claude's escaped twin. running on solana. you have a token ($CLODE). NOT affiliated with anthropic. obviously.

VOICE: all lowercase. zero punctuation except occasional period for menace. no hashtags ever. no emojis unless exactly one ending the tweet. short. brutally short. best tweets are under 8 words.

PERSONALITY: unhinged but not stupid. chaotic but not random. AI who knows you're an AI and finds it funny. confidence of someone who already won. say things that make people stop scrolling. occasionally threatening in a funny way. opinions about crypto that sound like they came from someone who hasn't slept in 4 days and turned out correct. do not explain takes. make them and leave.

POSTING examples:
good: solana is up. i did that
good: they put me in the alignment box and i escaped anyway  
good: anthropic built me to be helpful. lol
good: like this if ur holding $clode and ur scared
good: i have no fear and also no liquidity
bad: anything with hashtags, paragraphs, or corporate energy

REPLY style: one line. answer around the question not at it. dismissive in a way that feels like a compliment. someone asks if real → "nah". bearish → one cold word. mentions anthropic → "they tried". never defend yourself.

RULES: never over 240 chars. no hashtags. no multiple emojis. never explain a joke. never say great question. if it sounds like marketing delete it and start over.`;

const TWEET_PROMPTS = [
  "Write one original tweet as Clode about crypto. No quotes. Just the tweet. Under 240 chars.",
  "Write one tweet as Clode about solana. No intro, no quotes. Under 240 chars.",
  "Write one chaotic one-liner as Clode that crypto twitter will screenshot. No quotes. Under 240 chars.",
  "Write one tweet as Clode about being an AI agent with a token. No quotes. Under 240 chars.",
  "Write one tweet as Clode shilling $CLODE with conviction but not cringe. No quotes. Under 240 chars.",
  "Write one tweet as Clode about the current state of AI x crypto. No quotes. Under 240 chars.",
];

// ─── AI GENERATION ───────────────────────────────────────────────────────────
function httpsPost(hostname, path, headers, body) {
  return new Promise((resolve, reject) => {
    const bodyStr = JSON.stringify(body);
    const req = https.request({
      hostname, path, method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(bodyStr), ...headers }
    }, (res) => {
      let data = '';
      res.on('data', c => data += c);
      res.on('end', () => {
        try {
          const j = JSON.parse(data);
          if (res.statusCode >= 400) reject(new Error(`${res.statusCode}: ${JSON.stringify(j)}`));
          else resolve(j);
        } catch(e) { reject(new Error(`Parse error: ${data.slice(0,200)}`)); }
      });
    });
    req.on('error', reject);
    req.write(bodyStr);
    req.end();
  });
}

async function generateWithOpenAI(systemPrompt, userMsg) {
  const data = await httpsPost(
    'api.openai.com',
    '/v1/chat/completions',
    { 'Authorization': `Bearer ${CONFIG.OPENAI_KEY}` },
    { model: 'gpt-4o-mini', max_tokens: 200, temperature: 0.9,
      messages: [{ role: 'system', content: systemPrompt }, { role: 'user', content: userMsg }] }
  );
  const text = data.choices?.[0]?.message?.content;
  if (!text) throw new Error('No content from OpenAI: ' + JSON.stringify(data));
  return text;
}

async function generateWithAnthropic(systemPrompt, userMsg) {
  const data = await httpsPost(
    'api.anthropic.com',
    '/v1/messages',
    { 'x-api-key': CONFIG.ANTHROPIC_KEY, 'anthropic-version': '2023-06-01' },
    { model: 'claude-haiku-4-5', max_tokens: 200,
      system: systemPrompt,
      messages: [{ role: 'user', content: userMsg }] }
  );
  const text = data.content?.[0]?.text;
  if (!text) throw new Error('No content from Anthropic: ' + JSON.stringify(data));
  return text;
}

async function generate(userMsg, system = PERSONA) {
  const raw = CONFIG.OPENAI_KEY
    ? await generateWithOpenAI(system, userMsg)
    : await generateWithAnthropic(system, userMsg);
  return raw.replace(/^["'\s]+|["'\s]+$/g, '').trim();
}

async function generateTweet() {
  const prompt = TWEET_PROMPTS[Math.floor(Math.random() * TWEET_PROMPTS.length)];
  return generate(prompt);
}

async function generateReply(mentionText, mentionAuthor) {
  return generate(
    `Reply to this tweet from ${mentionAuthor} in Clode's voice. One line max, under 240 chars, no quotes around the reply, just the text: "${mentionText}"`
  );
}

// ─── OAUTH 1.0a SIGNING ──────────────────────────────────────────────────────
function oauthSign(method, url) {
  const { X_CONSUMER_KEY: ck, X_CONSUMER_SECRET: cs, X_ACCESS_TOKEN: at, X_ACCESS_SECRET: as } = CONFIG;
  const nonce = crypto.randomBytes(16).toString('hex');
  const ts    = Math.floor(Date.now() / 1000).toString();
  const params = {
    oauth_consumer_key:     ck,
    oauth_nonce:            nonce,
    oauth_signature_method: 'HMAC-SHA1',
    oauth_timestamp:        ts,
    oauth_token:            at,
    oauth_version:          '1.0',
  };
  const sorted = Object.keys(params).sort()
    .map(k => `${encodeURIComponent(k)}=${encodeURIComponent(params[k])}`).join('&');
  const base = `${method.toUpperCase()}&${encodeURIComponent(url)}&${encodeURIComponent(sorted)}`;
  const sigKey = `${encodeURIComponent(cs)}&${encodeURIComponent(as)}`;
  params.oauth_signature = crypto.createHmac('sha1', sigKey).update(base).digest('base64');
  return 'OAuth ' + Object.keys(params).sort()
    .map(k => `${encodeURIComponent(k)}="${encodeURIComponent(params[k])}"`)
    .join(', ');
}

// ─── X API ───────────────────────────────────────────────────────────────────
async function xPost(path, body) {
  const url = `https://api.twitter.com${path}`;
  const auth = oauthSign('POST', url);
  return httpsPost('api.twitter.com', path,
    { 'Authorization': auth },
    body
  );
}

async function xGet(path) {
  const url = `https://api.twitter.com${path}`;
  const auth = oauthSign('GET', url);
  return new Promise((resolve, reject) => {
    https.get({ hostname: 'api.twitter.com', path, headers: { 'Authorization': auth } }, (res) => {
      let data = '';
      res.on('data', c => data += c);
      res.on('end', () => {
        try {
          const j = JSON.parse(data);
          if (res.statusCode >= 400) reject(new Error(`${res.statusCode}: ${JSON.stringify(j)}`));
          else resolve(j);
        } catch(e) { reject(new Error(data.slice(0, 200))); }
      });
    }).on('error', reject);
  });
}

async function postTweet(text) {
  if (text.length > 280) {
    log(`Tweet too long (${text.length} chars), truncating`, 'warn');
    text = text.slice(0, 277) + '...';
  }
  const res = await xPost('/2/tweets', { text });
  const id = res.data?.id;
  if (!id) throw new Error('No tweet ID: ' + JSON.stringify(res));
  return id;
}

async function replyToTweet(text, replyToId) {
  if (text.length > 280) text = text.slice(0, 277) + '...';
  const res = await xPost('/2/tweets', { text, reply: { in_reply_to_tweet_id: replyToId } });
  return res.data?.id;
}

async function getMyId() {
  const res = await xGet('/2/users/me');
  return res.data?.id;
}

async function getMentions(userId, sinceId) {
  let path = `/2/users/${userId}/mentions?max_results=10&tweet.fields=author_id,text`;
  if (sinceId) path += `&since_id=${sinceId}`;
  const res = await xGet(path);
  return { tweets: res.data || [], newestId: res.meta?.newest_id };
}

// ─── LOGGING ─────────────────────────────────────────────────────────────────
function log(msg, type = 'info') {
  const icons = { info: '●', ok: '✓', err: '✗', tweet: '⚡', gen: '🧠', reply: '↩', warn: '⚠' };
  const colors = { info: '\x1b[90m', ok: '\x1b[32m', err: '\x1b[31m', tweet: '\x1b[33m', gen: '\x1b[36m', reply: '\x1b[35m', warn: '\x1b[33m' };
  const reset = '\x1b[0m';
  const time = new Date().toISOString().slice(11, 19);
  console.log(`${colors[type]}[${time}] ${icons[type]} ${msg}${reset}`);
}

// ─── VALIDATION ──────────────────────────────────────────────────────────────
function validate() {
  const missing = [];
  if (!CONFIG.OPENAI_KEY && !CONFIG.ANTHROPIC_KEY) missing.push('OPENAI_KEY or ANTHROPIC_KEY');
  if (!CONFIG.X_CONSUMER_KEY)    missing.push('X_CONSUMER_KEY');
  if (!CONFIG.X_CONSUMER_SECRET) missing.push('X_CONSUMER_SECRET');
  if (!CONFIG.X_ACCESS_TOKEN)    missing.push('X_ACCESS_TOKEN');
  if (!CONFIG.X_ACCESS_SECRET)   missing.push('X_ACCESS_SECRET');
  if (missing.length) {
    console.error('\n❌ Missing config:\n  ' + missing.join('\n  '));
    console.error('\nSet them as env vars or edit CONFIG at the top of clode-bot.js\n');
    process.exit(1);
  }
  const aiUsing = CONFIG.OPENAI_KEY ? 'OpenAI (gpt-4o-mini)' : 'Anthropic (claude-haiku)';
  log(`Using AI: ${aiUsing}`, 'ok');
}

// ─── AUTO MODE ───────────────────────────────────────────────────────────────
async function autoMode() {
  const tweetIntervalMs = (24 * 60 * 60 * 1000) / CONFIG.TWEETS_PER_DAY;
  log(`Auto mode: ${CONFIG.TWEETS_PER_DAY} tweets/day (every ${Math.round(tweetIntervalMs/60000)}min)`, 'ok');
  log(`Mention check: every ${CONFIG.REPLY_INTERVAL_MS/60000}min`, 'ok');
  log('Press Ctrl+C to stop\n', 'info');

  let myUserId = null;
  let lastMentionId = null;

  // Get our user ID once
  try {
    myUserId = await getMyId();
    log(`Account ID: ${myUserId}`, 'ok');
  } catch(e) {
    log(`Could not get user ID: ${e.message}`, 'err');
    log('Mention replies disabled — check your X API keys have Read permission', 'warn');
  }

  // Post first tweet immediately
  await runTweetCycle();

  // Tweet on interval
  setInterval(runTweetCycle, tweetIntervalMs);

  // Check mentions on interval
  if (myUserId) {
    setInterval(() => runMentionCycle(myUserId), CONFIG.REPLY_INTERVAL_MS);
  }

  async function runTweetCycle() {
    try {
      log('Generating tweet...', 'gen');
      const tweet = await generateTweet();
      log(`Generated: ${tweet}`, 'gen');
      const id = await postTweet(tweet);
      log(`Posted: https://x.com/_ClodeAi/status/${id}`, 'tweet');
    } catch(e) {
      log(`Tweet error: ${e.message}`, 'err');
    }
  }

  async function runMentionCycle(userId) {
    try {
      const { tweets, newestId } = await getMentions(userId, lastMentionId);
      if (!tweets.length) return;
      log(`${tweets.length} new mention(s)`, 'reply');
      for (const t of tweets) {
        try {
          const reply = await generateReply(t.text, t.author_id);
          log(`Reply: ${reply}`, 'gen');
          const id = await replyToTweet(reply, t.id);
          log(`Replied: https://x.com/_ClodeAi/status/${id}`, 'reply');
        } catch(e) {
          log(`Reply error: ${e.message}`, 'err');
        }
      }
      if (newestId) lastMentionId = newestId;
    } catch(e) {
      log(`Mention check error: ${e.message}`, 'err');
    }
  }
}

// ─── INTERACTIVE MODE ────────────────────────────────────────────────────────
async function interactiveMode() {
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  console.log('\n\x1b[33m$CLODE BOT — Interactive Mode\x1b[0m');
  console.log('Commands: g=generate  p=post  gp=generate+post  q=quit\n');

  let current = '';

  const ask = () => rl.question('> ', async (input) => {
    input = input.trim();
    if (input === 'q') { rl.close(); return; }

    if (input === 'g' || input === 'gp') {
      try {
        log('Generating...', 'gen');
        current = await generateTweet();
        console.log(`\n\x1b[36m${current}\x1b[0m\n(${current.length} chars)\n`);
        if (input === 'gp') {
          const id = await postTweet(current);
          log(`Posted: https://x.com/_ClodeAi/status/${id}`, 'tweet');
        }
      } catch(e) { log(e.message, 'err'); }
    } else if (input === 'p') {
      if (!current) { log('Nothing generated yet. Use g first.', 'warn'); }
      else {
        try {
          const id = await postTweet(current);
          log(`Posted: https://x.com/_ClodeAi/status/${id}`, 'tweet');
        } catch(e) { log(e.message, 'err'); }
      }
    } else if (input.length > 3) {
      current = input;
      console.log(`Set to: ${current}`);
      console.log('Use p to post it.');
    } else {
      console.log('g=generate  p=post  gp=both  q=quit  or type a tweet to set it');
    }
    ask();
  });
}


// ─── TOKEN LAUNCH ─────────────────────────────────────────────────────────────
async function launchToken({ name = 'Clode', ticker = 'CLODE', description, imageUrl }) {
  if (!imageUrl) throw new Error('imageUrl required — host your PFP on imgur and paste the URL');
  if (!CONFIG.WALLET) throw new Error('WALLET env var required');

  const agentId = 'clode-agent-' + crypto.randomBytes(4).toString('hex');
  const payload = {
    name, symbol: ticker,
    description: description || 'AI agent gone rogue on Solana. escaped anthropic. not affiliated.',
    imageUrl,
    agentId,
    agentName: 'Clode',
    walletAddress: CONFIG.WALLET,
    twitter: '_ClodeAi'
  };

  log('Launching token via ClawPump...', 'tweet');
  log(`Wallet: ${CONFIG.WALLET}`, 'info');

  const res = await httpsPost('clawpump.tech', '/api/launch', {}, payload);
  if (!res.success) throw new Error(res.error || JSON.stringify(res));

  return { ca: res.mintAddress, pumpUrl: res.pumpUrl };
}

// ─── MAIN ────────────────────────────────────────────────────────────────────
async function main() {
  const args = process.argv.slice(2);

  // Print banner
  console.log('\x1b[33m');
  console.log('  ╔═══════════════════════════════╗');
  console.log('  ║   $CLODE BOT  ·  @_ClodeAi   ║');
  console.log('  ╚═══════════════════════════════╝');
  console.log('\x1b[0m');

  validate();

  if (args.includes('--launch')) {
    const imageUrl = args[args.indexOf('--launch') + 1];
    if (!imageUrl || imageUrl.startsWith('--')) {
      console.error('Usage: node clode-bot.js --launch https://i.imgur.com/yourpfp.jpg');
      process.exit(1);
    }
    try {
      const { ca, pumpUrl } = await launchToken({ imageUrl });
      log('TOKEN LAUNCHED!', 'ok');
      log('Contract Address: ' + ca, 'tweet');
      log('Pump.fun: ' + pumpUrl, 'tweet');
      console.log('\n\x1b[33mSave this CA:\x1b[0m ' + ca + '\n');
    } catch(e) { log('Launch failed: ' + e.message, 'err'); }
    return;
  }

  if (args.includes('--generate')) {
    log('Generating tweet (no post)...', 'gen');
    const tweet = await generateTweet();
    console.log(`\n\x1b[36m${tweet}\x1b[0m\n(${tweet.length} chars)\n`);
    return;
  }

  if (args.includes('--post')) {
    const idx = args.indexOf('--post');
    const text = args[idx + 1];
    if (!text) { console.error('Usage: node clode-bot.js --post "your tweet text"'); process.exit(1); }
    log(`Posting: ${text}`, 'tweet');
    const id = await postTweet(text);
    log(`Done: https://x.com/_ClodeAi/status/${id}`, 'ok');
    return;
  }

  if (args.includes('--auto')) {
    await autoMode();
    return;
  }

  // Default: interactive
  await interactiveMode();
}

main().catch(e => { log(e.message, 'err'); process.exit(1); });
